import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ToastController } from 'ionic-angular';
import { TabsPage } from "../tabs/tabs";
import { LoginPage } from "../login/login";

/**
 * Generated class for the SignupPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-signup',
  templateUrl: 'signup.html',
})
export class SignupPage {

  constructor(public navCtrl: NavController, public navParams: NavParams, public toastCtrl: ToastController) {
  }


  presentToast(message: string) {
    let toast = this.toastCtrl.create({
      message: message,
      duration: 3000,
      position: 'bottom'
    });

    toast.present();

    return toast;
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad SignupPage');
  }

  username: string;
  password: string;
  cnfrpwd: string;

  signup() {
    if(this.username.length > 20) {
      this.presentToast("Length of username should be less than 20");
    }
    else if(this.password != this.cnfrpwd) {
      this.presentToast("Two passwords should be equivalent");
    }
    else if(this.password.length < 6 || this.password.length >20) {
      this.presentToast("Length of password should be between 6 and 20");
    }
    else {
      //send data to backend
      this.navCtrl.push(LoginPage);
    }
  }



}
